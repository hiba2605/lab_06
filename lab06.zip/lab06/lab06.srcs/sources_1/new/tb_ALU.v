`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09/25/2026 09:17:17 AM
// Design Name: 
// Module Name: tb_ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/1ps
module tb_ALU;
reg [31:0] A, B;
reg [3:0] ALUControl;
wire [31:0] ALUResult;
wire Zero;
ALU uut (
    .A(A),
    .B(B),
    .ALUControl(ALUControl),
    .ALUResult(ALUResult),
    .Zero(Zero)
);
initial begin
    A = 10; B = 5; ALUControl = 0;
    #10;
    
    A = 10; B = 5; ALUControl = 1;
    #10;

    A = 10; B = 5; ALUControl = 2;
    #10;

    A = 10; B = 5; ALUControl = 3;
    #10;

    A = 10; B = 5; ALUControl = 4;
    #10;
    
    A = 4; B = 2; ALUControl = 5;
    #10;
 
    A = 4; B = 2; ALUControl = 6;
    #10;
  
    A = 5; B = 5; ALUControl = 1;
    #10;
    $finish;
end
endmodule
