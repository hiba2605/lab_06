`timescale 1ns / 1ps

module tb_ALU_top;

    reg clk;
    reg pbin;
    reg [15:0] physical_sw;

    wire [15:0] physical_leds;

    ALU_top uut (
        .clk(clk),
        .pbin(pbin),
        .physical_sw(physical_sw),
        .physical_leds(physical_leds)
    );

    always #5 clk = ~clk;

    // Each switch value is held for 40 ns = 4 clock cycles, which is enough
    // for the FSM to complete a full READ -> DECODE -> DISPLAY loop (3
    // cycles) at least once, so the LEDs settle to the correct result
    // before the next switch value is applied.
    initial begin

        clk = 0;
        pbin = 0;
        physical_sw = 16'b0;

        // Pulse reset so the FSM starts cleanly in S_READ
        pbin = 1;
        #10;
        pbin = 0;

        #40;
        physical_sw = 16'b0000000000000000; // ADD

        #40;
        physical_sw = 16'b0000000000000001; // SUB

        #40;
        physical_sw = 16'b0000000000000010; // AND

        #40;
        physical_sw = 16'b0000000000000011; // OR

        #40;
        physical_sw = 16'b0000000000000100; // XOR

        #40;
        physical_sw = 16'b0000000000000101; // SLL

        #40;
        physical_sw = 16'b0000000000000110; // SRL

        #40;
        $finish;

    end

endmodule