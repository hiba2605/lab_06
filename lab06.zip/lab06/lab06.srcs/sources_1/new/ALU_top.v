`timescale 1ns / 1ps

module ALU_top(
    input wire clk,
    input wire pbin,
    input wire [15:0] physical_sw,
    output wire [15:0] physical_leds
);

    // ------------------------------------------------
    // FSM state encoding
    //   S_READ    : capture the current switch values
    //   S_DECODE  : translate the captured switches into ALUControl
    //   S_DISPLAY : latch ALUResult/Zero into the LED output register
    // The FSM loops READ -> DECODE -> DISPLAY -> READ -> ... forever,
    // so it is continuously re-reading the switches and re-displaying
    // the ALU result -- this is the "cycle" the FSM performs.
    // ------------------------------------------------
    localparam S_READ    = 3'b000;
    localparam S_DECODE  = 3'b001;
    localparam S_DISPLAY = 3'b010;

    // Reset
    wire rst_clean;

    // Switch data (raw, combinational passthrough from the leds/switch_reader block)
    wire [31:0] switch_data;

 
    reg [2:0]  state;
    reg [2:0]  next_state;
    reg [15:0] sw_reg;     
    reg [15:0] leds_reg;   


    reg  [3:0]  ALUControl;
    wire [31:0] ALUResult;
    wire        Zero;

    wire [31:0] A = 32'h10101010;
    wire [31:0] B = 32'h01010101;


    debouncer rat_db (
        .clk(clk),
        .pbin(pbin),
        .pbout(rst_clean)
    );


  

    leds switch_reader (
        .clk(clk),
        .rst(rst_clean),
        .btns(16'd0),
        .writeData(32'd0),
        .writeEnable(1'b0),
        .readEnable(1'b1),
        .memAddress(30'd0),
        .switches(physical_sw),
        .readData(switch_data)
    );


 

    always @(posedge clk) begin
        if (rst_clean) begin
            state    <= S_READ;
            sw_reg   <= 16'd0;
            leds_reg <= 16'd0;
        end else begin
            state <= next_state;

            case (state)
                S_READ:
                    sw_reg <= switch_data[15:0];  

                S_DISPLAY:
                    leds_reg <= {Zero, ALUResult[14:0]}; 

                default: ; 
            endcase
        end
    end

    always @(*) begin
        case (state)
            S_READ:    next_state = S_DECODE;
            S_DECODE:  next_state = S_DISPLAY;
            S_DISPLAY: next_state = S_READ;
            default:   next_state = S_READ;
        endcase
    end


    always @(*) begin
        case (sw_reg[2:0])
            3'b000: ALUControl = 4'b0000; // ADD
            3'b001: ALUControl = 4'b0001; // SUB
            3'b010: ALUControl = 4'b0010; // AND
            3'b011: ALUControl = 4'b0011; // OR
            3'b100: ALUControl = 4'b0100; // XOR
            3'b101: ALUControl = 4'b0101; // SLL
            3'b110: ALUControl = 4'b0110; // SRL
            default: ALUControl = 4'b0000;
        endcase
    end



    ALU alu1 (
        .A(A),
        .B(B),
        .ALUControl(ALUControl),
        .ALUResult(ALUResult),
        .Zero(Zero)
    );

    assign physical_leds = leds_reg;

endmodule